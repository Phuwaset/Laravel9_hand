<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <script src="<?php echo e(asset('assets/js/jquery/jquery-3.6.4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery/time.js')); ?>"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com/%22%3E
    <link rel="preconnect"
        href="https://fonts.gstatic.com/" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Prompt:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">

    <script src="<?php echo e(asset('assets/js/times.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/logout.js')); ?>"></script>


</head>

<body>

    <div class="grid grid-cols-3 gap-4">
        <div class="p-2"></div>

        <div class="p-2 text">
            <br>
            <br>
            <br>

            ชื่อผู้ใช้งาน :
            <br><br>
            Persernal :
            <br><br>
            Department :
            <br><br>

            <div class="text-center">

                <button class="p-2.5 bg-blue-500 text-white w-200  hover:bg-blue-400" id="myBtn">Open Modal</button>


                <br><br>

                <h1>
                    <p data-time="" id="timer">0 seconds </p>
                </h1>
            </div>
        </div>
        <div class="p-2">
            <div class="flex flex-col items-end">
                <div>
                    <img src="<?php echo e(asset('assets/image/logo.png')); ?>" class=" text-center  w-20 mr-4 " alt="">
                    <button class="p-2.5 bg-white rounded-md hover:bg-slate-50" id="logout_btn">Logout</button>
                </div>
            </div>
        </div>
    </div>




    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
        }

        /* The Modal (background) */
        .modal {
            display: none;
            /* Hidden by default */
            position: fixed;
            /* Stay in place */
            z-index: 1;
            /* Sit on top */
            padding-top: 100px;
            /* Location of the box */
            left: 0;
            top: 0;
            width: 100%;
            /* Full width */
            height: 100%;
            /* Full height */
            overflow: auto;
            /* Enable scroll if needed */
            background-color: rgb(0, 0, 0);
            /* Fallback color */
            background-color: rgba(0, 0, 0, 0.4);
            /* Black w/ opacity */
        }

        /* Modal Content */
        .modal-content {
            background-color: #fefefe;
            margin: auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
        }

        /* The Close Button */
        .close {
            color: #aaaaaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: #000;
            text-decoration: none;
            cursor: pointer;
        }
    </style>
    </head>

    <body>


        <!-- The Modal -->
        <div id="myModal" class="modal">

            <!-- Modal content -->
            <div class="modal-content">
                <span class="close">&times;</span>
                <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike">
                <label for="vehicle1"> Step : 1</label><br><br>

                <input type="checkbox" id="vehicle2" name="vehicle2" value="Car">
                <label for="vehicle2"> Step : 2</label><br><br>

                <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                <label for="vehicle3"> Step : 3</label><br><br>

                <input type="checkbox" id="vehicle4" name="vehicle3" value="Boat">
                <label for="vehicle3"> Step : 4</label><br><br>

                <input type="checkbox" id="vehicle5" name="vehicle3" value="Boat">
                <label for="vehicle3">Step : 5</label><br><br>

                <input type="checkbox" id="vehicle6" name="vehicle3" value="Boat">
                <label for="vehicle3"> Step : 6</label><br><br>

                <input type="checkbox" id="vehicle7" name="vehicle3" value="Boat">
                <label for="vehicle3"> Step : 7</label><br><br>

                <button id="start" class="p-2.5 bg-blue-500 text-white w-20  hover:bg-blue-400">Start</button>

                <button value="5" id="stop" class="p-2.5 bg-blue-500 text-white w-20  hover:bg-blue-400 left-500"
                    name="stop">Stop</button>

            </div>

        </div>

        <script>
            // Get the modal
            var modal = document.getElementById("myModal");

            // Get the button that opens the modal
            var btn = document.getElementById("myBtn");

            // Get the <span> element that closes the modal
            var span = document.getElementsByClassName("close")[0];

            // When the user clicks the button, open the modal 
            btn.onclick = function() {
                modal.style.display = "block";
            }

            // When the user clicks on <span> (x), close the modal
            span.onclick = function() {
                modal.style.display = "none";
            }

            // When the user clicks anywhere outside of the modal, close it
            window.onclick = function(event) {
                if (event.target == modal) {
                    modal.style.display = "none";
                }
            }
        </script>

        
<button onclick="dash()" id="next" class="inline-block py-7.5 px-10 mx-10 mb-2text-lg font-medium leading-10 text-center   text-[#bb1b2b] bg-[#ecedf0] -300 rounded-xl shadow-md hover:bg-white -400active:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-offset-2focus:ring-gray-500">
            LET'S GO
        </button>

       <script>
            let countdown;
            let timerDisplay = document.getElementById('timer');
            let check = 0;
        </script>
        <script src="test.js"></script> 
    </body>

</html>
<?php /**PATH C:\xampp\htdocs\hospit\hand_hygiene\resources\views/timeClock.blade.php ENDPATH**/ ?>