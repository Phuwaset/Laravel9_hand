
<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <script src="<?php echo e(asset('assets/js/jquery/jquery-3.6.4.min.js')); ?>"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Prompt:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">


    <script src="<?php echo e(asset('assets/js/insertINTO.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/logout.js')); ?>"></script>
</head>

<body>
    <div class="flex flex-col items-end">
        <div>
            <img src="<?php echo e(asset('assets/image/logo.png')); ?>" class=" text-center  w-20 mr-4 " alt="">
            <button class="p-2.5 bg-white rounded-md hover:bg-slate-50" id="logout_btn">Logout</button>
        </div>
    </div>
    <div class="grid grid-cols-3 gap-4">
        <div class="p-2"></div>

        <div class="p-2">
           
            username : <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($row-> username); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
            <hr><br>
            <label for="countries" class="block mb-2 text-sm font-medium text-gray-900 text-dark">
                Department :
            </label>

            <select
                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 "
                id="option_department">
                <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($row->id); ?>"><?php echo e($row->department_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <script></script>
            <br>

            <label for="countries" class="block mb-2 text-sm font-normal text-gray-900 dark:text-dark">Personal
                :</label>

            <select
                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                id="option_personal">
                <?php $__currentLoopData = $persernal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($row->id); ?>"><?php echo e($row->personal_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </select>
            <br>

            <label for="countries" class="block mb-2 text-sm font-normal text-gray-900 dark:text-dark">Type OF:</label>

            <select
                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg
                 focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                id="option_type">

                <option value="1" selected>HAND WASH</option>
                <option value="2">HAND RUB</option>
            </select>
            <br>

            <label for="countries" class="block mb-2 text-sm font-normal text-gray-900 dark:text-dark">Moment :</label>
            <select
                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg
                 focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                id="option_moment">
                <option value="1" selected>Before Touching Patient</option>
                <option value="2">Before Aseptic Procedure</option>
                <option value="3">After Touching A Patient</option>
                <option value="4">After Touching Patient Surrounding</option>
            </select>
            <br>
            <button class="p-2.5 bg-blue-500 text-white w-full rounded-md hover:bg-blue-400"
                id="insert"></a>next</a></button>
        </div>
        </form>
    </div>
</body>

</html>
<?php /**PATH E:\develop\hand_hygiene\resources\views/insert.blade.php ENDPATH**/ ?>