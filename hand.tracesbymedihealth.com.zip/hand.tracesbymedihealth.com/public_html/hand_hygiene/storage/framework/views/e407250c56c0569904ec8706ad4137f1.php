<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <script src="<?php echo e(asset('assets/js/jquery/jquery-3.6.4.min.js')); ?>"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Prompt:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">
    <script src="<?php echo e(asset('assets/js/insertINTO.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/logout.js')); ?>"></script>
</head>


<body>
    <div class="flex flex-col items-end">
        <div>
            <img src="<?php echo e(asset('assets/image/logo.png')); ?>" class=" text-center  w-20 mr-4 " alt="">
            <button class="p-2.5 bg-white rounded-md hover:bg-slate-50" id="logout_btn">Logout</button>
        </div>
    </div>
    <div class="grid grid-cols-3 gap-4">

        <div class="p-2"></div>

        <div class="p-2 text">
     

            ชื่อผู้ใช้งาน :  <?php echo e(dd($department)); ?>

            <br><br>
            Persernal :
            <br><br>
            Department :
            <br><br>



            <div class="text-center">
                <p id="timer" style="font-size: 36px;">0 seconds</p>
                <button id="start" class="p-2.5 bg-blue-500 text-white w-20  hover:bg-blue-400"
                    onclick="startCountdown()">Start</button>

                <button id="stop" class="p-2.5 bg-blue-500 text-white w-20  hover:bg-blue-400"
                    onclick="stopCountdown()">Stop</button>






            </div>
            <div class="p-2">

            </div>
        </div>

        <script>
            let countdown;
            let timerDisplay = document.getElementById('timer');
            let check = 0;

            function startCountdown() {
                let seconds = 20;

                countdown = setInterval(function() {
                    seconds--;
                    check++;
                    timerDisplay.textContent = seconds + ' seconds';

                    if (seconds === 0) {
                        clearInterval(countdown);
                        alert('หมดเวลา ใช้เวลาทั้งหมด ' + check + ' ' + 'วินาที');
                        check = 0;
                    }
                }, 1000);
            }

            // ฟังก์ชั่นหยุดการนับเวลา
            function stopCountdown() {
                clearInterval(countdown);
                alert('ใช้เวลาทั้งหมด' + check + ' ' + 'วินาที');
                check = 0;
            }
        </script>

</body>

</html>
<?php /**PATH E:\develop\hand_hygiene\resources\views/settime.blade.php ENDPATH**/ ?>